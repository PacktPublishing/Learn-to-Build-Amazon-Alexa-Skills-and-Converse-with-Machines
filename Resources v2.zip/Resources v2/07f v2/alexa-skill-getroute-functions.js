const https = require("https");

const myfunctions = {
  // Take out the quote and return author as well as quote
  getQuote: function(quotes, author) {
    console.log("Getting into getQuoteFunction");

    // Get random author if author is not defined
    if (author === undefined) {
      var totalauthors = Object.keys(quotes).length;
      var rand = Math.floor(Math.random() * totalauthors);

      // random author name
      author = Object.keys(quotes)[rand];
    }

    // check the author if it exists, and have a single author name
    switch (author) {
      case "Lincoln":
        author = "Lincoln";
        break;
      case "Abraham Lincoln":
        author = "Lincoln";
        break;
      case "Abe Lincoln":
        author = "Lincoln";
        break;
      case "Einstein":
        author = "Einstein";
        break;
      case "Albert Einstein":
        author = "Einstein";
        break;
      default:
        author = "Unknown";
    }

    // Get total quotations for the author from the QuoteDataObj object
    var totalquotations = quotes[author].length;

    // Select a random quotation
    var randquote = Math.floor(Math.random() * totalquotations);
    var quote = quotes[author][randquote];

    console.log("Return author and quote");

    // return both the author name and quote as an array
    return [author, quote];
  },
  // Make an HTTP Request and retrieve data either through GET or POST
  getData: function(options, postData) {
    return new Promise(function(resolve, reject) {
      var request = https.request(options, function(response) {
        // reject if status is not 2xx
        if (response.statusCode < 200 || response.statusCode >= 300) {
          return reject(new Error("statusCode=" + response.statusCode));
        }

        // cumulate data
        var body = [];
        response.on("data", function(chunk) {
          body.push(chunk);
        });

        // process once ended
        response.on("end", function() {
          try {
            body = JSON.parse(Buffer.concat(body).toString());
            // use just 'body' for non JSON input
          } catch (error) {
            reject(error);
          }
          resolve(body);
        });
      });

      // manage other request errors
      request.on("error", function(error) {
        reject(error);
      });

      // Post Data (optional)
      if (postData) {
        request.write(postData);
      }

      // End the request. It's Important
      request.end();
    }); // promise ends
  }
};

module.exports = myfunctions;

/*
const http = require("https");
const actions = {
    httpRequest: async function (params, postData) {
    return new Promise(function(resolve, reject) {
        var req = http.request(params, function(res) {
            // reject on bad status
            if (res.statusCode < 200 || res.statusCode >= 300) {
                return reject(new Error('statusCode=' + res.statusCode));
            }
            // cumulate data
            var body = [];
            res.on('data', function(chunk) {
                body.push(chunk);
            });
            // resolve on end
            res.on('end', function() {
                try {
                    body = body;//JSON.parse(Buffer.concat(body).toString());
                }
                catch (e) {
                    reject(e);
                }
                resolve(body);
            });
        });
        // reject on request error
        req.on('error', function(err) {
            // This is not a "Second reject", just a different sort of failure
            reject(err);
        });
        if (postData) {
            req.write(postData);
        }
        // IMPORTANT
        req.end();
    });
}
};

module.exports = actions;
*/
